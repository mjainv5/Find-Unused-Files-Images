//
//  ViewLeaveViewController.m
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "ViewLeaveViewController.h"
#import "ViewLeaveTableViewCell.h"
#import "ViewLeaveDetailViewController.h"

#define kTableCellIdentifier @"TableCellIdentifier"

@interface ViewLeaveViewController ()<UITableViewDelegate, UITableViewDataSource>
{
    NSMutableArray *arrLeaveOption;
}
@end

@implementation ViewLeaveViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [tblViewLeave registerNib:[UINib nibWithNibName:@"ViewLeaveTableViewCell" bundle:nil] forCellReuseIdentifier:kTableCellIdentifier];
    
    [self addPickerForYearField];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)addPickerForYearField
{
    arrLeaveOption = [[NSMutableArray alloc] initWithObjects:@"All",@"Applied",@"First Level Approved",@"Second Level Approved",@"Cancelled",@"First Level Rejected",@"Second Level Rejected", nil];
    txtFieldSelectOption.inputView = pickerLeaveType;
    [pickerLeaveType reloadAllComponents];
}

#pragma mark - Picker View Data source

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    
    return [arrLeaveOption count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    
    return [NSString stringWithFormat:@"%@",[arrLeaveOption objectAtIndex:row]];
}

#pragma mark - UITouch delegate

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [pickerLeaveType setHidden:YES];
};
#pragma mark- Picker View Delegate

-(void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    txtFieldSelectOption.text = [NSString stringWithFormat:@"%@",[arrLeaveOption objectAtIndex:row]];
    [pickerLeaveType setHidden:YES];
    
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [pickerLeaveType setHidden:NO];
    return NO;
}

#pragma mark - tableview delategate and datasource methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return 5;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ViewLeaveTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kTableCellIdentifier];
    //    [cell setContentToCell:[_arrWorksheetForTableDataSource objectAtIndex:selectedIndexPath.row] tagNo:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self pushPunchAttendanceController:indexPath.row];
}

-(void)pushPunchAttendanceController:(NSInteger)rowIndex
{
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Dashboard" bundle:nil];
    ViewLeaveDetailViewController *vc = [mainStoryBoard instantiateViewControllerWithIdentifier:@"ViewLeaveDetail"];
    [self.navigationController pushViewController:vc animated:YES];
}
@end

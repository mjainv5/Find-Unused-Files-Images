//
//  ViewAttendanceViewController.h
//  Sample
//
//  Created by Mohit Jain on 8/28/15.
//
//

#import <UIKit/UIKit.h>

@interface ViewAttendanceViewController : UIViewController
{
    __weak IBOutlet UITableView *tblViewAttendance;
}
@end

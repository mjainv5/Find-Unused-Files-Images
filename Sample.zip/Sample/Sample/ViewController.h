//
//  ViewController.h
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    __weak IBOutlet UITextField *txtFieldLogin;
    __weak IBOutlet UIButton *btnLogin;
}
- (IBAction)btnLoginTapped:(id)sender;

@end


//
//  DashboardViewController.m
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "DashboardViewController.h"
#import "PunchAttendanceViewController.h"
#import "ViewLeaveViewController.h"
#import "Constants.h"
#import "LocationManager.h"
@interface DashboardViewController ()

@end

@implementation DashboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Location enable
    [[LocationManager sharedInstance] startUpdatingLocation];
    
    [btnPunch.layer setCornerRadius:5];
    [btnPunch.layer setBorderColor:kBackgroundColor];
    [btnPunch.layer setBorderWidth:1];
    
    [btnViewAttendance.layer setCornerRadius:5];
    [btnViewAttendance.layer setBorderColor:kBackgroundColor];
    [btnViewAttendance.layer setBorderWidth:1];
    
    [btnViewLEave.layer setCornerRadius:5];
    [btnViewLEave.layer setBorderColor:kBackgroundColor];
    [btnViewLEave.layer setBorderWidth:1];
    
    [btnApplyLeave.layer setCornerRadius:5];
    [btnApplyLeave.layer setBorderColor:kBackgroundColor];
    [btnApplyLeave.layer setBorderWidth:1];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark -IBAction Methods

- (IBAction)btnPunchAttendanceTapped:(id)sender{
    [self pushPunchAttendanceController];
}

- (IBAction)btnViewAttendanceTapped:(id)sender{
    [self pushViewAttendanceController];
}

- (IBAction)btnApplyLeaveTapped:(id)sender{
    
}

- (IBAction)btnViewLeaveTapped:(id)sender {
    [self pushViewLeaveController];
}

#pragma mark - PushViewController Methods

-(void)pushPunchAttendanceController{
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Dashboard" bundle:nil];
    PunchAttendanceViewController *vc = [mainStoryBoard instantiateViewControllerWithIdentifier:@"PunchAttendance"];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)pushViewLeaveController{
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Dashboard" bundle:nil];
    ViewLeaveViewController *vc = [mainStoryBoard instantiateViewControllerWithIdentifier:@"ViewLeave"];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)pushViewAttendanceController{
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Dashboard" bundle:nil];
    ViewLeaveViewController *vc = [mainStoryBoard instantiateViewControllerWithIdentifier:@"ViewAttendance"];
    [self.navigationController pushViewController:vc animated:YES];
}
@end

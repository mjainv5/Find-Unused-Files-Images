//
//  ServerConnection.m
//
//  Created by Mohit Jain on 1/15/14.
//

#import "ServerConnection.h"
#import "Reachability.h"
#import "AppDelegate.h"

@interface ServerConnection() <NSXMLParserDelegate>

@end

@implementation ServerConnection
{
    NSString  *currentDescription;
}
@synthesize responseData;

- (void)serverConnection:(NSMutableURLRequest*)request target:(id)target selector:(SEL)selector
{
    _delegate = target;
    _handler = selector;
    if ([self checkNetworkConnectivity])
    {
        NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject
                                                                     delegate:self
                                                                delegateQueue:[NSOperationQueue mainQueue]];
        NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:request];
        [dataTask resume];
    }
}

#pragma mark - Delegate Methods for NSUrlSession

- (void)URLSession:(NSURLSession *)session
          dataTask:(NSURLSessionDataTask *)dataTask didReceiveResponse:(NSURLResponse *)response
 completionHandler:(void (^)(NSURLSessionResponseDisposition disposition))completionHandler
{
    responseData = [[NSMutableData alloc] init];
    completionHandler(NSURLSessionResponseAllow);
}

- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data
{
    [responseData appendData:data];
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error
{
    if (_isResponseNotNeed)
    {
        return;
    }
    if(error == nil)
    {
        if(responseData.length != 0)
        {
            NSLog(@"DONE. Received Bytes: %lu", (unsigned long)[responseData length]);
            NSString *theXML = [[NSString alloc] initWithBytes:
                                [responseData mutableBytes] length:[responseData length] encoding:NSUTF8StringEncoding];
            
            NSData *myData = [theXML dataUsingEncoding:NSUTF8StringEncoding];
            
            NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithData:myData];
            
            // Don't forget to set the delegate!
            xmlParser.delegate = self;
            
            // Run the parser
            BOOL parsingResult = [xmlParser parse];
            
        }
    }
    else
    {
        
    }
}
-(void) parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:
(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    currentDescription = [NSString alloc];
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    currentDescription = string;
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(BOOL)checkNetworkConnectivity
{
    Reachability *internetReach = [Reachability reachabilityForInternetConnection];
    [internetReach startNotifier];
    
    NetworkStatus internetStatus = [internetReach currentReachabilityStatus];
    
    switch(internetStatus)
    {
        case NotReachable:
        {
            return NO;
        }
        case ReachableViaWiFi:
        {
            return YES;
        }
        case ReachableViaWWAN:
        {
            return YES;
        }
    }
    return YES;
}
@end

//
//  ServerConnection.h
//
//  Created by Mohit Jain on 1/15/14.
//

#import <Foundation/Foundation.h>

@interface ServerConnection : NSObject <NSURLConnectionDelegate,NSURLSessionDelegate>
{
    id              _delegate;
    SEL             _handler;
    NSMutableData*  responseData;
}

@property (retain, nonatomic) NSMutableData*  responseData;

@property BOOL isResponseNotNeed;
@property BOOL isResponseNotRequiredWhenFail;

//Methods
- (void)serverConnection:(NSMutableURLRequest*)connection target:(id)target selector:(SEL)selector;

@end

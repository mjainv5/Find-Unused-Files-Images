//
//  RequestBuilder.m
//  
//
//  Created by Mohit Jain on 1/15/14.
//  Copyright (c) 2014 Nancy Kashyap. All rights reserved.
//

#import "RequestBuilder.h"
#define timeoutTime 120
@implementation RequestBuilder

 + (NSMutableURLRequest*)request:(NSURL*)requestUrl requestType:(NSString*)requestType parameters:(NSString *)soapMessage
{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    NSURL *url = [NSURL URLWithString:@"http://w3schools.com/webservices/tempconvert.asmx"];
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
    NSString *msgLength = [NSString stringWithFormat:@"%lu", (unsigned long)[soapMessage length]];
    [theRequest addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [theRequest addValue: @"http://tempuri.org/CelsiusToFahrenheit" forHTTPHeaderField:@"SOAPAction"];
    [theRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
    [theRequest setHTTPMethod:@"POST"];
    [theRequest setHTTPBody: [soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
    return request;
}


@end
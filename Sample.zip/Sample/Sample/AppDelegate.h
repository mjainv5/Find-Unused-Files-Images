//
//  AppDelegate.h
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  PunchAttendanceViewController.h
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "ViewController.h"

@interface PunchAttendanceViewController : ViewController
{

    __weak IBOutlet UIButton *btnPunchIn;
    __weak IBOutlet UIButton *btnPunchOut;
}
- (IBAction)btnPunchInTapped:(id)sender;
- (IBAction)btnPunchOutTapped:(id)sender;
@end

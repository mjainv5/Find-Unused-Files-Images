//
//  ViewLeaveViewController.h
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "ViewController.h"

@interface ViewLeaveViewController : ViewController
{

    __weak IBOutlet UITextField *txtFieldSelectOption;
    __weak IBOutlet UITableView *tblViewLeave;
 
    __weak IBOutlet UIPickerView *pickerLeaveType;
}
@end

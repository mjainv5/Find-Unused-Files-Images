//
//  OtpCheckViewController.m
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "OtpCheckViewController.h"
#import "AppDelegate.h"
@interface OtpCheckViewController ()

@end

@implementation OtpCheckViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [btnValidateTapped.layer setCornerRadius:5];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnValidateTapped:(id)sender
{
    
    [self openDashboard];
    
}

-(void)openDashboard
{
    UIStoryboard *dashboard = [UIStoryboard storyboardWithName:@"Dashboard" bundle:nil];
    UINavigationController *objViewController = (UINavigationController *)[dashboard instantiateViewControllerWithIdentifier:@"DashnboardNav"];
    
    AppDelegate *delegate = [[UIApplication sharedApplication] delegate];
    UIWindow *window = delegate.window;
    
    [window setRootViewController:objViewController];
    
}

@end

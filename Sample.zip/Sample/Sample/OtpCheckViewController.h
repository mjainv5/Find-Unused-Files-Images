//
//  OtpCheckViewController.h
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "ViewController.h"

@interface OtpCheckViewController : ViewController
{

    __weak IBOutlet UITextField *txtFieldOTP;
    __weak IBOutlet UIButton *btnValidateTapped;
}
- (IBAction)btnValidateTapped:(id)sender;

@end

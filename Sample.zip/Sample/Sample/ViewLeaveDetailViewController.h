//
//  ViewLeaveDetailViewController.h
//  Sample
//
//  Created by Mohit Jain on 8/27/15.
//
//

#import "ViewController.h"

@interface ViewLeaveDetailViewController : ViewController
{
    __weak IBOutlet UIView *viewContainer;
}
@end

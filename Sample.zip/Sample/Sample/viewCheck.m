//
//  viewCheck.m
//  Sample
//
//  Created by Mohit Jain on 8/27/15.
//
//

#import "viewCheck.h"

@implementation viewCheck

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

//
//  LocationManager.h
//  iPhoneCalculator
//
//  Created by Mohit Jain on 8/28/15.
//  Copyright (c) 2015 Fructivity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationManager : UIViewController
+ (instancetype)sharedInstance;
- (void)startUpdatingLocation;


@end

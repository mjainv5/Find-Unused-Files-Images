//
//  Constants.h
//  Sample
//
//  Created by Mohit Jain on 8/27/15.
//
//

#import <Foundation/Foundation.h>

@interface Constants : NSObject

#define kBackgroundColor [UIColor colorWithRed:24.0/255.0f green:56.0/255.0f blue:131.0/255.0f alpha:1.0f].CGColor
#define UIColorCellDarak [UIColor colorWithRed:195/255.0f green:240/255.0f blue:255/255.0f alpha:1.0f]
#define UIColorCellLight [UIColor colorWithRed:231/255.0f green:249/255.0f blue:255/255.0f alpha:1.0f]


@end

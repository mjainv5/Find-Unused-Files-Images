//
//  ViewLeaveDetailViewController.m
//  Sample
//
//  Created by Mohit Jain on 8/27/15.
//
//

#import "ViewLeaveDetailViewController.h"
#import "Constants.h"

@interface ViewLeaveDetailViewController ()

@end

@implementation ViewLeaveDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [viewContainer.layer setBorderColor:kBackgroundColor];
    [viewContainer.layer setBorderWidth:1];
    [viewContainer.layer setCornerRadius:5];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

//
//  ViewAttendanceTableViewCell.h
//  Sample
//
//  Created by Mohit Jain on 8/28/15.
//
//

#import <UIKit/UIKit.h>

@interface ViewAttendanceTableViewCell : UITableViewCell

@end

//
//  ViewController.m
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "ViewController.h"
#import "OtpCheckViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:self.navigationItem.backBarButtonItem.style target:nil action:nil];
    
    [btnLogin.layer setCornerRadius:5];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnLoginTapped:(id)sender
{
    [self pushOtpCheckController];
}

-(void)pushOtpCheckController
{
     UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    OtpCheckViewController *vc = [mainStoryBoard instantiateViewControllerWithIdentifier:@"OtpCheck"];
    [self.navigationController pushViewController:vc animated:YES];
}

@end

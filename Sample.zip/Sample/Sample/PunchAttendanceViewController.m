//
//  PunchAttendanceViewController.m
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "PunchAttendanceViewController.h"

@interface PunchAttendanceViewController ()

@end

@implementation PunchAttendanceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [btnPunchIn.layer setCornerRadius:5];
    [btnPunchOut.layer setCornerRadius:5];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnPunchInTapped:(id)sender {
}

- (IBAction)btnPunchOutTapped:(id)sender {
}
@end

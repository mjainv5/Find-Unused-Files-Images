//
//  ViewLeaveTableViewCell.m
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "ViewLeaveTableViewCell.h"
#import "Constants.h"

@implementation ViewLeaveTableViewCell

- (void)awakeFromNib {
    // Initialization code
    [viewContainer.layer setBorderColor:[UIColor grayColor].CGColor];
    [viewContainer.layer setBorderWidth:1];
    [viewContainer.layer setCornerRadius:5];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  ViewAttendanceViewController.m
//  Sample
//
//  Created by Mohit Jain on 8/28/15.
//
//

#import "ViewAttendanceViewController.h"
#import "ViewAttendanceTableViewCell.h"
#import "Constants.h"
#define kTableCellIdentifier @"CellIdentifier"


@interface ViewAttendanceViewController ()

@end

@implementation ViewAttendanceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:self.navigationItem.backBarButtonItem.style target:nil action:nil];

    [tblViewAttendance registerNib:[UINib nibWithNibName:@"ViewAttendanceTableViewCell" bundle:nil] forCellReuseIdentifier:kTableCellIdentifier];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - tableview delategate and datasource methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return 30;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ViewAttendanceTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kTableCellIdentifier];
    //    [cell setContentToCell:[_arrWorksheetForTableDataSource objectAtIndex:selectedIndexPath.row] tagNo:indexPath.row];
    if (indexPath.row%2 == 0) {
        [cell setBackgroundColor:UIColorCellLight];
    }
    else
    {
        [cell setBackgroundColor:UIColorCellDarak];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

@end

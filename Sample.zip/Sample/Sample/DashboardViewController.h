//
//  DashboardViewController.h
//  Sample
//
//  Created by Mohit Jain on 8/26/15.
//
//

#import "ViewController.h"

@interface DashboardViewController : ViewController
{
    __weak IBOutlet UIButton *btnPunch;
    __weak IBOutlet UIButton *btnViewAttendance;
    __weak IBOutlet UIButton *btnApplyLeave;
    __weak IBOutlet UIButton *btnViewLEave;
}
- (IBAction)btnPunchAttendanceTapped:(id)sender;
- (IBAction)btnViewAttendanceTapped:(id)sender;
- (IBAction)btnApplyLeaveTapped:(id)sender;
- (IBAction)btnViewLeaveTapped:(id)sender;
@end

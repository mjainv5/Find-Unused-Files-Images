//
//  appAppDelegate.h
//  Contacts_List
//
//  Created by Mohit Jain on 21/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface appAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

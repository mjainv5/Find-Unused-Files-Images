//
//  addContactViewController.h
//  Contacts_List
//
//  Created by Mohit Jain on 21/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface addContactViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    NSArray *contactArray;
    UIImagePickerController *imagePicker;
    NSString *imgPath;
}
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
- (IBAction)myAddContact:(id)sender;
- (IBAction)btnImagePicker:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *myPhoneNo;
@property NSString *databasePath;
@property (weak, nonatomic) IBOutlet UITextField *myName;
- (IBAction)btnCancel:(id)sender;
@property sqlite3 *infoDb;
@end


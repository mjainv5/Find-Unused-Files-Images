//
//  appViewController.m
//  Contacts_List
//
//  Created by Mohit Jain on 21/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import "appViewController.h"

@interface appViewController ()

@end

@implementation appViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)swipe:(UISwipeGestureRecognizer *)recognizer
{
    
    NSString * storyboardName = @"MainStoryboard";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
//UIViewController *vc=[storyboard ins]
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"ContactviewController"];
 

   [self presentViewController:vc animated:YES completion:nil];
}
@end

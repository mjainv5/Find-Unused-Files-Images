//
//  addContactViewController.m
//  Contacts_List
//
//  Created by Mohit Jain on 21/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import "addContactViewController.h"
@interface addContactViewController ()
{
    NSData *imageData;

}
@end

@implementation addContactViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _imgView.image=[UIImage imageNamed:@"defaultContactImage.jpg"];

	// Do any additional setup after loading the view.
    imagePicker = [[UIImagePickerController alloc] init];
    NSString *path;
    NSArray *documentDir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    path=documentDir[0];
    _databasePath=[[NSString alloc]initWithString:[path stringByAppendingPathComponent:@"contacts.db"]];
    const char *dbPath=[_databasePath UTF8String];
    char * err;
    NSLog(@"%@",_databasePath);
    if((sqlite3_open(dbPath, &_infoDb))==SQLITE_OK)
    {
        const char *sql_stmt =
        "CREATE TABLE IF NOT EXISTS User ( NAME TEXT, PHONE TEXT,IMAGE BLOB)";
        sqlite3_exec(_infoDb, sql_stmt,nil,nil,&err);
        sqlite3_close(_infoDb);

    }
    UIImageView *View = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 100, 50)];
    View.image = [UIImage imageNamed:@"player.jpeg"];
}
- (IBAction)myAddContact:(id)sender
{
    [_myPhoneNo resignFirstResponder];
    [_myName resignFirstResponder];
    NSString * name=_myName.text;
    NSString * phone=_myPhoneNo.text;    const char *dbPath=[_databasePath UTF8String];
    const char *err;
 if([name length]!=0 && [phone length]!=0)
 {
     
    /*if((sqlite3_open(dbPath, &_infoDb))==SQLITE_OK)
    {
        char *err;
        NSString * query=[NSString stringWithFormat:@"INSERT INTO User (NAME, PHONE,IMAGE) VALUES (\"%@\",\"%@\",?)",name,phone];
        
    
        sqlite3_bind_blob(query, 2,  [imageData bytes], [imageData length], NULL);
        
        NSLog(@"Query: %@",query);
        
       
        sqlite3_exec(_infoDb, sql_stmt,nil,nil,&err);
        sqlite3_close(_infoDb);
        NSLog(@"Error: %s",err);
        
        UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Contact" message:@"Data Saved" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alertBox show];
//        NSLog(@"%@",_databasePath);
        [self performSegueWithIdentifier:@"ContactviewController" sender:sender];
    }*/
     sqlite3_stmt *compiledStmt;
     if(sqlite3_open(dbPath, &_infoDb)==SQLITE_OK)
     {
         const char *insertSQL="INSERT INTO User(NAME,PHONE,IMAGE)values(?,?,?)";
         if(sqlite3_prepare_v2(_infoDb,insertSQL, -1, &compiledStmt, &err)==SQLITE_OK)
         {

         sqlite3_bind_text(compiledStmt,1,[name UTF8String],-1,SQLITE_TRANSIENT);
         sqlite3_bind_text(compiledStmt,2,[phone UTF8String],-1,SQLITE_TRANSIENT);
      
         sqlite3_bind_blob(compiledStmt, 3,  [imageData bytes], [imageData length], SQLITE_TRANSIENT);
         
             sqlite3_step(compiledStmt);
         }
      
     }
     UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Contact" message:@"Data Saved" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
     [alertBox show];
 
     [self performSegueWithIdentifier:@"ContactviewController" sender:sender];
     
 
 }
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
   UIImage *img;
   NSURL *mediaUrl;
   mediaUrl=(NSURL *)[info valueForKey:UIImagePickerControllerOriginalImage];
   img=(UIImage  * )[info valueForKey:UIImagePickerControllerOriginalImage];
    imageData=UIImagePNGRepresentation(img);
    
    
    NSLog(@"\nIMage%@",[info valueForKey:UIImagePickerControllerOriginalImage]);
  
    
    [_imgView setImage:img];
    
    [picker dismissModalViewControllerAnimated:YES];
   
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissModalViewControllerAnimated:YES];
}

- (IBAction)btnImagePicker:(id)sender {
    imagePicker.delegate=self;
    imagePicker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentModalViewController:imagePicker animated:YES];
    
  }
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnCancel:(id)sender {
     [self performSegueWithIdentifier:@"ContactviewController" sender:sender];
}
@end

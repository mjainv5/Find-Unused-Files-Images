//
//  CallContact.h
//  Contacts_List
//
//  Created by Mohit Jain on 26/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface _CallContact : UIViewController

- (IBAction)back:(id)sender;
@end

//
//  appCell.h
//  Contacts_List
//
//  Created by Mohit Jain on 21/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface appCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgContactPerson;
@property (weak, nonatomic) IBOutlet UILabel *lblContactName;
@property (weak, nonatomic) IBOutlet UILabel *lblContactNumber;

@end

//
//  ContactList.m
//  Contacts_List
//
//  Created by Mohit Jain on 21/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import "ContactList.h"
#import "appCell.h"
#import "EditContact.h"
@interface ContactList ()
{
    int flag;
    NSArray *searchResults;
    int index;
}
@end

@implementation ContactList

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    flag=1;
    NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"SELF contains[cd] %@",
                                    searchText];
    NSLog(@"BYEE%@",resultPredicate);
    searchResults = [contactName filteredArrayUsingPredicate:resultPredicate];
    
    for(id objname in searchResults)
    {
        NSLog(@"Name= %@ Phone %@\n",objname,dictContact[objname][0]);
    }
    [_tblContactList reloadData];
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller
shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString
                               scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                      objectAtIndex:[self.searchDisplayController.searchBar
                                                     selectedScopeButtonIndex]]];
    NSLog(@"HELLOO");
    return YES;
}
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    flag=0;
    NSLog(@"ENDDDDDDDD");
    [self loadContacts];
}


- (void)loadContacts
{
   NSLog(@"Load Contacts \n");
    if(flag==0){
        [contactName removeAllObjects];
        [contactImage removeAllObjects];
        [contactNumber removeAllObjects];
        [dictContact removeAllObjects];
        
    }
    // Do any additional setup after loading the view.
    NSString *path;
    NSArray *documentDir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    path=documentDir[0];
    _databasePath=[[NSString alloc]initWithString:[path stringByAppendingPathComponent:@"contacts.db"]];
    const char *dbPath=[_databasePath UTF8String];
    
    sqlite3_stmt *statement;
    if (sqlite3_open(dbPath, &_infoDb) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:
                              @"SELECT * FROM User ORDER BY NAME COLLATE NOCASE"];
        
        const char *query_stmt = [querySQL UTF8String];
        
        if (sqlite3_prepare_v2(_infoDb,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK)
        {
            while  (SQLITE_DONE!= sqlite3_step(statement))
            {
                
                NSString *name = [[NSString alloc]
                                  initWithUTF8String:(const char *) sqlite3_column_text(statement, 0)];
//                NSLog(@"Name: %@",name);
                [contactName addObject:name];
                
                int a = sqlite3_column_int(statement, 1);
                NSString *phoneField = [NSString stringWithFormat:@"%d",a];
                
                [contactNumber addObject:phoneField];
                
                NSData *imageData=[[NSData alloc]initWithBytes:sqlite3_column_blob(statement, 2) length:sqlite3_column_bytes(statement, 2)];
                [contactImage addObject:imageData];
                [dictContact setObject:[NSArray arrayWithObjects:phoneField,imageData, nil] forKey:name];
            }
            sqlite3_finalize(statement);
        }
        sqlite3_close(_infoDb);
    }
     [_tblContactList reloadData];
    NSLog(@"Contacts End\n");
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    flag=0;
    contactNumber=[[NSMutableArray alloc]init];
    contactName=[[NSMutableArray alloc]init];
    contactImage=[[NSMutableArray alloc]init];
    dictContact=[[NSMutableDictionary alloc]init];
    
    [self loadContacts];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"appCell";
    
    appCell *cell = (appCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"appCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    if(flag==0)
    {
        cell.lblContactName.text=[contactName objectAtIndex:indexPath.row];
        cell.lblContactNumber.text=[contactNumber objectAtIndex:indexPath.row];
        cell.imgContactPerson.image=[UIImage imageWithData:[contactImage objectAtIndex:indexPath.row]];
    }
    else    
    {
       cell.lblContactName.text=[searchResults objectAtIndex:indexPath.row];
       NSString *objName=(NSString *)[searchResults objectAtIndex:indexPath.row];
       cell.lblContactNumber.text=dictContact[objName][0];
       cell.imgContactPerson.image=[UIImage imageWithData:dictContact[objName][1]];
    }
    
    UIButton *btnCall=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnCall.frame = CGRectMake(cell.frame.origin.x + 280, cell.frame.origin.y + 10, 30, 30);
    
    [btnCall setImage:[UIImage imageNamed:@"Phone-icon.png" ] forState:UIControlStateNormal];
    [btnCall addTarget:self action:@selector(callPressed:) forControlEvents:UIControlEventTouchUpInside];
     btnCall.tag=indexPath.row;
     btnCall.backgroundColor= [UIColor clearColor];
    
    [cell.contentView addSubview:btnCall];
    return cell;
}
-(IBAction)callPressed:(id)sender
{
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(flag==0)
    {
        return [contactName count];
    }
    else
    {
        return [searchResults count];
    }
}

- (IBAction)btnAddContact:(id)sender {

    [self performSegueWithIdentifier:@"viewController" sender:sender];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"index path=%ld",(long)indexPath.row);
    selectedindex=indexPath;
    
    [self performSegueWithIdentifier:@"editController" sender:nil];
    NSLog(@"didSelected\n");
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
//    NSLog(@"prepare fOR segue\n");
    if([segue.identifier isEqualToString:@"editController"])
        {
            EditContact *destContoller=segue.destinationViewController;
            appCell *selectedCell=(appCell *)[self.tblContactList cellForRowAtIndexPath:selectedindex];
            destContoller.contactName=selectedCell.lblContactName.text;
            destContoller.contactNumber=selectedCell.lblContactNumber.text;
        }
}
@end













/*


 rough

 NSString *path;
 NSArray *documentDir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
 path=documentDir[0];
 _databasePath=[[NSString alloc]initWithString:[path stringByAppendingPathComponent:@"information.db"]];
 //NSFileManager *file=[NSFileManager defaultManager];
 //if([file fileExistsAtPath:_databasePath]==NO)
 //{
 const char *dbPath=[_databasePath UTF8String];
 char * err;
 NSLog(@"%@",_databasePath);
 if((sqlite3_open(dbPath, &_infoDb))==SQLITE_OK)
 {
 const char *sql_stmt =
 "CREATE TABLE IF NOT EXISTS User ( NAME TEXT, PASSWORD TEXT)";
 sqlite3_exec(_infoDb, sql_stmt,nil,nil,&err);
 sqlite3_close(_infoDb);
 NSLog(@"Error: %s",err);
 
 }
 //}
 // Do any additional setup after loading the view, typically from a nib.
 }
 
 - (void)didReceiveMemoryWarning
 {
 [super didReceiveMemoryWarning];
 // Dispose of any resources that can be recreated.
 }
 
 - (IBAction)login:(id)sender {
 
 const char *dbPath=[_databasePath UTF8String];
 if((sqlite3_open(dbPath, &_infoDb))==SQLITE_OK)
 {
 char *err;
 NSString * query=[NSString stringWithFormat:@"INSERT INTO User (NAME, PASSWORD) VALUES (\"%@\",\"%@\")",_loginUserName.text,_loginPassword.text];
 NSLog(@"Query: %@",query);
 const char *sql_stmt =[query UTF8String];
 sqlite3_exec(_infoDb, sql_stmt,nil,nil,&err);
 sqlite3_close(_infoDb);
 NSLog(@"Error: %s",err);
 
 UIAlertView *alertBox=[[UIAlertView alloc]initWithTitle:@"Database" message:@"Data Saved" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
 [alertBox show];
 NSLog(@"%@",_databasePath);
 
 }
 
 sqlite3_stmt *statement;
 
 
 if (sqlite3_open(dbPath, &_infoDb) == SQLITE_OK)
 {
 NSString *querySQL = [NSString stringWithFormat:
 @"SELECT * FROM User"];
 
 const char *query_stmt = [querySQL UTF8String];
 
 if (sqlite3_prepare_v2(_infoDb,
 query_stmt, -1, &statement, NULL) == SQLITE_OK)
 {
 while  (SQLITE_DONE!= sqlite3_step(statement))
 {
 
 //if (sqlite3_step(statement) == SQLITE_ROW)
 //{
 NSString *addressField = [[NSString alloc]
 initWithUTF8String:
 (const char *) sqlite3_column_text(
 statement, 0)];
 NSLog(@"Name: %@",addressField);
 NSString *phoneField = [[NSString alloc]
 initWithUTF8String:(const char *)
 sqlite3_column_text(statement, 1)];
 NSLog(@"Password: %@",phoneField);
 //  _status.text = @"Match found";
 } //se {
 //NSLog(@"Inside else");
 //_status.text = @"Match not found";
 // _address.text = @"";
 // _phone.text = @"";
 //}
 sqlite3_finalize(statement);
 }
 else {
 
 NSLog(@"middle else");
 }
 sqlite3_close(_infoDb);
 }
 else{
 NSLog(@"outside else");
 }
 }
 @end
*/
//
//  EditContact.m
//  Contacts_List
//
//  Created by Mohit Jain on 25/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import "EditContact.h"

@interface EditContact ()

@end

@implementation EditContact

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _imgPerson.opaque=NO;
    
    // Do any additional setup after loading the view.
    NSString *path;
    NSArray *documentDir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    path=documentDir[0];
    _databasePath=[[NSString alloc]initWithString:[path stringByAppendingPathComponent:@"contacts.db"]];
    const char *dbPath=[_databasePath UTF8String];
    
    sqlite3_stmt *statement;
    if (sqlite3_open(dbPath, &_infoDb) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:
                              @"SELECT IMAGE FROM User WHERE NAME=\"%@\" and PHONE=\"%@\"",_contactName,_contactNumber];
         
        NSLog(@"Query=%@",querySQL);
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(_infoDb,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK)
        {
            if(SQLITE_DONE!=sqlite3_step(statement))
            {
                _imageData=[[NSData alloc]initWithBytes:sqlite3_column_blob(statement, 0) length:sqlite3_column_bytes(statement, 0)];
//            NSLog(@"iMAGE dATA=%@",_imageData);
            }
            
            sqlite3_finalize(statement);
        }
        sqlite3_close(_infoDb);
    }
    _lblContactName.text=_contactName;
    _lblContactNo.text =_contactNumber;
    
    _imgPerson.image=[UIImage imageWithData:_imageData];
//    NSLog(@"%@",[contactImage objectAtIndex:1]);

}

- (IBAction)btnBack:(id)sender
{
    [self performSegueWithIdentifier:@"ContactViewController" sender:sender];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnCall:(id)sender
{
    NSString *phoneNumber = [@"telprompt://" stringByAppendingString:_contactNumber];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
//    [self performSegueWithIdentifier:@"CallContact" sender:sender];
}
@end

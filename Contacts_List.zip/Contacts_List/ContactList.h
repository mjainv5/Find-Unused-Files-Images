//
//  ContactList.h
//  Contacts_List
//
//  Created by Mohit Jain on 21/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import "appViewController.h"
#import "appCell.h"
#import "sqlite3.h"
@interface ContactList : UIViewController<UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchDisplayDelegate>
{
    NSMutableArray *contactName;
    NSMutableArray *contactNumber;
    NSMutableArray *contactImage;
    NSMutableDictionary *dictContact;
    NSIndexPath * selectedindex;
}
- (IBAction)btnAddContact:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tblContactList;
@property (weak, nonatomic) IBOutlet UISearchBar *searchBox;
@property NSString *databasePath;

@property sqlite3 *infoDb;
@end

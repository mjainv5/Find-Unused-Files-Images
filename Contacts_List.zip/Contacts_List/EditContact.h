//
//  EditContact.h
//  Contacts_List
//
//  Created by Mohit Jain on 25/02/14.
//  Copyright (c) 2014 Net Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
@interface EditContact : UIViewController
{
   // NSMutableArray *contactName;
    //NSMutableArray *contactNumber;
   // NSMutableArray *contactImage;
    NSMutableDictionary *dictContact;

}
@property (weak, nonatomic) IBOutlet UIImageView *imgPerson;
@property (weak, nonatomic) IBOutlet UILabel *lblContactNo;
- (IBAction)btnBack:(id)sender;

@property (weak, nonatomic) IBOutlet UILabel *lblContactName;
- (IBAction)btnCall:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnBack;
@property NSString *databasePath;
@property sqlite3 *infoDb;

@property NSString *contactName;
@property NSString *contactNumber;
@property NSData *imageData;
@end
